package org.example.MyLibrary;

public enum TypePort {
    ANALOG,
    DIGITAL
}