package org.example.MyLibrary;

public interface SupsiSensor {
    int getSensorID();
}